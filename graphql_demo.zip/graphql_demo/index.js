import express from 'express';
import resolvers from './resolvers';
import schema from './schema';
import { graphqlHTTP } from 'express-graphql';

const app = express();

app.get("/", (req, res) => {
    res.send("Hey Noob");
})

// const root = { lco: () => console.log("Learn.in") }
const root = resolvers;
app.use('/graphql', graphqlHTTP({
        schema: schema,
        rootValue: root,
        graphiql: true
    }))
    //true for UI http://localhost:8082/graphql
app.listen(8082, () => console.log("App started 8082"));