import { buildSchema } from 'graphql';

const schema = buildSchema(`
    type Course {
        id: ID
        name: String
        courselist: [String]
        category: [Categories]
        state: State
        price: Float
    }

    type Categories {
        tech:String
        nontech:String
    }

    enum State {
        MAH
        DEL
        UP
    }

    type Query {
        getCourse(id:ID):Course
    }

    input CourseInput {
        id: ID
        name: String!
        courselist: [String]
        category: [CategoriesInput]
        state: State
        price: Float!
    }

    input CategoriesInput {
        tech:String
        nontech:String
    }

    type Mutation {
        createCourse(input: CourseInput): Course
    }
`)
export default schema;