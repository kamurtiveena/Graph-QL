import { nanoid } from 'nanoid';

class Course {
    constructor(id, {
        name,
        courselist,
        category,
        state,
        price,
    }) {
        this.id = id
        this.name = name
        this.courselist = courselist
        this.category = category
        this.state = state
        this.price = price
    }
}

//use actual DB
const courseholder = {}

const resolvers = {
    getCourse: ({ id }) => {
        return new Course(id, courseholder[id])
    },
    createCourse: ({ input }) => {
        let id = nanoid()
        courseholder[id] = input
        return new Course(id, input)
    }
}

export default resolvers;