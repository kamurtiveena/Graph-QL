# lco-graphql
A standard babel setup
Starter project setup for upcoming crash courses
